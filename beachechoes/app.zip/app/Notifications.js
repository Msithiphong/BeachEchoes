import React from 'react';
import { StyleSheet, Text, View, Pressable } from 'react-native';
import * as Notifications from 'expo-notifications';

// 1. Configure how the app handles notifications when it's open
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function NotificationsScreen() {
  
  const handlePress = async () => {
    // 2. Request Permissions
    const { status } = await Notifications.requestPermissionsAsync();
    
    if (status !== 'granted') {
      alert('Permission to send notifications was denied!');
      return;
    }

    // 3. Trigger a local notification immediately
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "Success! 🔔",
        body: "Your first React Native notification is working.",
        data: { screen: 'Notifications' },
      },
      trigger: null, // 'null' makes it happen immediately
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Notification Tester</Text>
      <Text style={styles.subtitle}>Test your local triggers here</Text>

      <Pressable 
        onPress={handlePress} 
        style={({ pressed }) => [
          styles.button,
          { backgroundColor: pressed ? '#005bb5' : '#007AFF' }
        ]}
      >
        <Text style={styles.buttonText}>Send Notification</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  subtitle: { fontSize: 16, color: '#666', marginBottom: 30 },
  button: { paddingVertical: 15, paddingHorizontal: 30, borderRadius: 10 },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: '600' },
});